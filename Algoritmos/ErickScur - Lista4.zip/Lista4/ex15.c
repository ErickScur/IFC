#include <stdio.h>
#include <locale.h>
#define TAM 3

int main (){
    setlocale(LC_ALL, "Portuguese_Brazil");

    char origem,destino;
    int a,b,tabela[7][7] =
        {
        {0, 2, 11, 6, 15, 11, 1},
        {2, 0, 7, 12, 4, 2, 15},
        {11, 7, 0, 11, 8, 3, 13},
        {6, 12, 11, 0, 10, 2, 1},
        {15, 4, 8, 10, 0, 5, 13},
        {11, 2, 3, 2, 5, 0, 14},
        {1, 15, 13, 1, 13, 14, 0}
        }; 

    do{
        printf("Informe a cidade origem(a,b,c,d,e,f ou g) \n");
        scanf("%c",&origem);
        getchar();

        printf("Informe a cidade destino(a,b,c,d,e,f ou g) \n");
        scanf("%c",&destino);
        getchar();

        if(origem!=destino){
            switch(origem){
                case 'a':
                    a=0;
                    break;
                case 'b':
                    a=1;
                    break;
                case 'c':
                    a=2;
                    break;
                case 'd':
                    a=3;
                    break;
                case 'e':
                    a=4;
                    break;
                case 'f':
                    a=5;
                    break;
                case 'g':
                    a=6;
                    break;
                default:
                    printf("cidade invalida\n");
                    a=-1;
                    break;
            }
            switch(destino){
                case 'a':
                    b=0;
                    break;
                case 'b':
                    b=1;
                    break;
                case 'c':
                    b=2;
                    break;
                case 'd':
                    b=3;
                    break;
                case 'e':
                    b=4;
                    break;
                case 'f':
                    b=5;
                    break;
                case 'g':
                    b=6;
                    break;
                default:
                    printf("cidade invalida\n");
                    b=-1;
                    break;
            }
            if(a>=0 && b>=0)
                printf("%d horas! \n",tabela[a][b]);
        }else{
            printf("fim do programa!");
            break;
        }
        
    }while(origem!=destino);
    
    return 0;
}

