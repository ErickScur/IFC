#include <stdio.h>
#include <locale.h>
#define TAM 5

//Faça um programa em C que leia a idade e a altura de 5 pessoas, armazene cada informação no seu respectivo vetor. 
//Imprima a idade e a altura na ordem inversa a ordem lida.


int main (){
    setlocale(LC_ALL, "Portuguese_Brazil");

    int i,idades[TAM];
    float alturas[TAM];

    for(i=0;i<TAM;i++){
        printf("Informe a idade: %d/%d \n",i+1,TAM);
        scanf("%d",&idades[i]);

        printf("Informe a altura: %d/%d \n",i+1,TAM);
        scanf("%f",&alturas[i]);
    }
    printf("\n Idades: \n");
    for(i=TAM-1;i>=0;i--){
        printf("%d ",idades[i]);
    }

    printf("\n Alturas: \n");
    for(i=TAM-1;i>=0;i--){
        printf("%f ",alturas[i]);
    }
    
    return 0;
}


 