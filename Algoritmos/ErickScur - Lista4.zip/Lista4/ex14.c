#include <stdio.h>
#define TAM 10
//Leia uma matriz 10 x 10 que se refere respostas de 10 questões de múltipla escolha, referentes a 10 alunos.
// Leia também um vetor de 10 posições contendo o gabarito de respostas que podem ser a, b, c ou d. 
//Seu programa deverá comparar as respostas de cada candidato com o gabarito e emitir um vetor Resultado, contendo a pontuação correspondente.


int main (){
    int i,j;
    char respostas[TAM][TAM],gabarito[TAM];
    int resultado[TAM];

    for(i=0;i<TAM;i++){ //coloca todos os resultados como 0
        resultado[i]=0;
    }

    for(i=0;i<TAM;i++){
      printf("Informe as respostas do aluno %d: \n",i+1);
      for(j=0;j<TAM;j++){
        printf("Questao %d/%d (a, b, c ou d) \n",j+1,TAM);
        scanf("%c",&respostas[i][j]);
        getchar();
      }
    }
    for(i=0;i<TAM;i++){
        printf("Informe o gabarito da questao %d\n",i+1);
        scanf("%c",&gabarito[i]);
        getchar();
    }
    for(i=0;i<TAM;i++){
      for(j=0;j<TAM;j++){
        if(respostas[i][j]==gabarito[i]){
            resultado[i]++;
        }
      }
    }
    printf("Resultado:\n");
    for(i=0;i<TAM;i++){
        printf("Aluno %d: %d pontos\n",i,resultado[i]);
    }
    return 0;
}

