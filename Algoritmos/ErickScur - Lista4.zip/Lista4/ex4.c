#include <stdio.h>
#include <locale.h>
#define TAM 12

//Ler do teclado 12 números inteiros e armazená-los em um vetor N. Em seguida, copiar os elementos pares divisíveis por 3 para o vetor
// X e os ímpares divisíveis por 5 para o vetor Y.


int main (){
    setlocale(LC_ALL, "Portuguese_Brazil");

    int i, n[TAM],x[TAM],y[TAM],contX=0,contY=0;

    for(i=0;i<TAM;i++){
        printf("Informe o valor: %d/%d \n",i+1,TAM);
        scanf("%d",&n[i]);
    }

    for(i=0;i<TAM;i++){
        if((n[i]%2==0) && (n[i]%3==0)){
            x[contX] = n[i];
            contX++;
        }else if((n[i]%2!=0)&&(n[i]%5==0)){
            y[contY]= n[i];
            contY++;
        }
    }
    return 0;
}

