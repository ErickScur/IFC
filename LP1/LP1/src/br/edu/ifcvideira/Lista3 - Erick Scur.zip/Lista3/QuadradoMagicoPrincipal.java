package br.edu.ifcvideira.Lista3;

public class QuadradoMagicoPrincipal {
	public static void main(String[] args) {
		int[][] matriz = {
				{2,7,6},
				{9,5,1},
				{4,3,8}
		};
		boolean quadrado = QuadradoMagico.QuadradoMagico(matriz);
	}
}
